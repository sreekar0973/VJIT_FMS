document.addEventListener('DOMContentLoaded', function () {
  //SUBMIT BUTTON IN INDEX PAGE
  const submitButton = document.getElementById("submitbutton");
  if(submitButton)
  submitButton.addEventListener('click', function (event) {
    let password = document.getElementById("password").value;
      event.preventDefault();
      fetchData()
      .then(data=>{
        console.log(data);
        if(data.accountType==="admin" && password == data.password){
          alert("sucessful");
          window.location.assign("adminpages/admin_dashboard.html");
        }
        else if(data.accountType=== "user" && password == data.password){
          alert("sucessful");
          window.location.assign("userpages/user_dashboard.html");
        }
        else if(data.accountType==="facilitator" && password == data.password){
          alert("sucessful");
          window.location.assign("facilitatorpages/facilitator_dashboard.html");
          }
        else{
          alert("unsucessfull");
        }
        
      })
      
  });
  /*async function authenticate()
{
  let username = document.getElementById("username").value;
  
return await fetch("http://localhost:8080/profiles/getProfilePassword?userId="+username).then((data)=>{
  console.log(data);
  return data.json();//convert to object
    });
}*/
async function fetchData() {
  let username = document.getElementById("username").value;
return await fetch('http://localhost:8080/profiles/getProfilePassword?userId='+username)
      .then(response => response.json()) // Parse response as JSON
      .then(data => {
          // Store data in local storage
          localStorage.setItem('data', JSON.stringify(data));
          console.log('Data stored locally');
          return data;
      })
      .catch(error => {
          console.error('Error fetching data:', error);
      });
}

});





