document.addEventListener('DOMContentLoaded', function () {
      //SUBMIT BUTTON IN INDEX PAGE
      const submitButton = document.getElementById("submit");
      if(submitButton)
      submitButton.addEventListener('click', function (event) {
          event.preventDefault();
      const value = localStorage.getItem('data');
      const Object = JSON.parse(value);
          var formData = {
            workDescription : document.getElementById("workDescription").value,
            workLocation : document.getElementById("workLocationBlock").value+" "+document.getElementById("workLocationRoom").value,
            workRequestorId : Object.userId,
            department:document.getElementById("department").value
          };
          fetchData(formData);
          
      });
    async function fetchData(data) {
      
    return await  fetch('http://localhost:8080/works/addWork', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response;
    })
    .then(data => {
      console.log('Success:', data);
      // Handle successful response from backend
      alert("Successfully Raise a Complaint");
    })
    .catch(error => {
      console.error('Error:', error);
      // Handle errors
    });
          
    }
    
    });
    
    
    
    
    
    