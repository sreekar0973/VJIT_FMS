const table_body=document.getElementById("table_body")
const value = localStorage.getItem('data');
const Object = JSON.parse(value);
fetch("http://localhost:8080/works/getWorkStatusByUserId?userId="+Object.userId).then((data)=>{
      console.log(data);//json format
      return data.json();//convert to object
}).then((objectData)=>{
      console.log(objectData);
      let tableData="";
      objectData.map((values)=>{
            tableData+=`<tr>
            <td>${values.workDescription}</td>
            <td>${values.workLocation}</td>
            <td>${values.workStatus}</td>
            <td>${values.workAssignerId}</td>
            </tr>`
      });
      if(table_body)
      table_body.innerHTML=tableData;
});