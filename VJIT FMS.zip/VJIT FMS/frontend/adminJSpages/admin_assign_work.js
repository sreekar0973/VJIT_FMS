document.addEventListener('DOMContentLoaded', function () {
  //SUBMIT BUTTON IN INDEX PAGE
  FacilitatorType=document.getElementById('FacilitatorType')
  if(FacilitatorType)
  FacilitatorType.addEventListener('change', function() {
    var selectedOption = this.value;
    fetch("http://localhost:8080/profiles/getFacilitatorsByType?role="+selectedOption).then((data)=>{
      console.log(data);//json format
      return data.json();//convert to object
}).then((objectData)=>{
  const select = document.getElementById('Facilitator');
  while (select.options.length > 0) {
    select.remove(0);
}
const optionElement = document.createElement('option');
      optionElement.value = "";
      optionElement.textContent = "--select--";
      select.appendChild(optionElement);
  objectData.forEach(option => {
      const optionElement = document.createElement('option');
      optionElement.value = option.userId;
      optionElement.textContent = option.name;
      select.appendChild(optionElement);
});
});
});
Facilitator=document.getElementById('Facilitator')
  if(Facilitator)
  Facilitator.addEventListener('change', function() {
    var selectedOption = this.value;
    document.getElementById("facilitatorId").value=selectedOption;

  });

  const submitButton = document.getElementById("submit");
  const workId = document.getElementById("workId");
  const workDescription = document.getElementById("workDescription");
  const workLocation= document.getElementById("workLocation");
  const value = localStorage.getItem('work');
  const Object = JSON.parse(value);
  workId.value=Object.workId;
  workDescription.value=Object.workDescription;
  workLocation.value=Object.workLocation;

  if(submitButton)
  submitButton.addEventListener('click', function (event) {
      event.preventDefault();
      var formData = {
        workId : document.getElementById("workId").value,
        workAssignerId : document.getElementById("facilitatorId").value
      };
      fetchData(formData);
      
  });
async function fetchData(data) {
  
return await  fetch('http://localhost:8080/works/assignWork', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
})
.then(response => {
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response;
})
.then(data => {
  console.log('Success:', data);
  // Handle successful response from backend
  alert("Successfully Assigned a Complaint");
})
.catch(error => {
  console.error('Error:', error);
  // Handle errors
});
      
}

});





