const table_body=document.getElementById("table_body")
fetch("http://localhost:8080/profiles/facilitators").then((data)=>{
      console.log(data);//json format
      return data.json();//convert to object
}).then((objectData)=>{
      console.log(objectData);
      let tableData="";
      objectData.map((values)=>{
            tableData+=`<tr>
            <td>${values.userId}</td>
            <td>${values.name}</td>
            <td>${values.gmail}</td>
            <td>${values.contactDetails}</td>
           </tr>`
      });
      if(table_body)
      table_body.innerHTML=tableData;
});