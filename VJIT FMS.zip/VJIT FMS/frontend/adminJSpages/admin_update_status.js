document.addEventListener('DOMContentLoaded', function () {
      //SUBMIT BUTTON IN INDEX PAGE
      const submitButton = document.getElementById("submit");
      
  const workId = document.getElementById("workId");
  const workDescription = document.getElementById("workDescription");
  const workLocation= document.getElementById("workLocation");
  const value = localStorage.getItem('updateWork');
  const Object = JSON.parse(value);
  workId.value=Object.workId;
  workDescription.value=Object.workDescription;
  workLocation.value=Object.workLocation;

      if(submitButton)
      submitButton.addEventListener('click', function (event) {

          event.preventDefault();
          var formData = {
            workId : Object.workId,
            status : "completed"
          };
          fetchData(formData);
          
      });
    async function fetchData(data) {
      
    return await  fetch('http://localhost:8080/works/updateStatus', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response;
    })
    .then(data => {
      console.log('Success:', data);
      // Handle successful response from backend
      alert("Successfully Updated");
    })
    .catch(error => {
      console.error('Error:', error);
      // Handle errors
    });
          
    }
    
    });
    
    
    
    
    
    