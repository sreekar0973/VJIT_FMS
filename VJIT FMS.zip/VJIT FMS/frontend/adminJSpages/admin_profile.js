document.addEventListener('DOMContentLoaded', function () {
      const username = document.getElementById("username");
      const gmail = document.getElementById("gmail");
      const profession = document.getElementById("profession");
      const contactDetails = document.getElementById("contactDetails");
      const localStorageContent = JSON.stringify(localStorage, null, 2);
      console.log(localStorageContent);
      const value = localStorage.getItem('data');
      const Object = JSON.parse(value);
      username.textContent=Object.name; 
      gmail.textContent=Object.gmail;
      contactDetails.textContent=Object.contactDetails;
      profession.textContent=Object.accountType;

});