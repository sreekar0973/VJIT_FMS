const table_body=document.getElementById("table_body")
fetch("http://localhost:8080/works/getVerifyingWorksByDepartment?department=MECH").then((data)=>{
      console.log(data);//json format
      return data.json();//convert to object
}).then((objectData)=>{
      console.log(objectData);
      let tableData="";
      objectData.map((values)=>{
            tableData+=`<tr>
            <td>${values.workId}</td>
            <td>${values.workDescription}</td>
            <td>${values.workLocation}</td>
            <td> <button type="button" class="btn btn-outline-success" onclick="showRowContent(this)">Assign</button><td>
           </tr>`
      });
      if(table_body)
      table_body.innerHTML=tableData;
});
function showRowContent(button) {
      var row = button.parentNode.parentNode;
      var cells = row.getElementsByTagName("td");
      var content = "";
      var formData = {
            workId:cells[0].textContent,
            workDescription : cells[1].textContent,
            workLocation : cells[2].textContent,
            workStatus : cells[3].textContent
          };
          localStorage.setItem('work', JSON.stringify(formData));
          console.log('Data stored locally');
         const value = localStorage.getItem('work');
         const Object = JSON.parse(value);
         console.log(Object.workId);
         alert("WorkId:"+Object.workId+"\n"+"WorkDescription:"+Object.
         workDescription+"\nWorkLocation:"+Object.workLocation);
         window.location.assign("../admin_assign_work.html");
  }