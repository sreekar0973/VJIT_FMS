package com.sreekar.CFMS.model;

import lombok.Data;

@Data
public class AssignWork {
    private Integer workId;
    private String workAssignerId;
}
