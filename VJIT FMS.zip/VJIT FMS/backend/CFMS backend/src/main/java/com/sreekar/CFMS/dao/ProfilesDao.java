package com.sreekar.CFMS.dao;

import com.sreekar.CFMS.model.Profiles;
import com.sreekar.CFMS.model.ProfilesWrapper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProfilesDao extends JpaRepository<Profiles,String> {
    @Query(value = "SELECT * FROM profiles p where p.user_id=:userId",nativeQuery = true)
Profiles findProfilesByUserId(String userId);
    @Query(value = "SELECT * FROM profiles p where p.account_type='facilitator'",nativeQuery = true)
    List<Profiles> findFacilitators();
    @Query(value = "SELECT * FROM profiles p where p.account_type='facilitator' and p.role=:role",nativeQuery = true)

    List<Profiles> findFacilitatorsByType(String role);
}