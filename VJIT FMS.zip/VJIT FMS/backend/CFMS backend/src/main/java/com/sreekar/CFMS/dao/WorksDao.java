package com.sreekar.CFMS.dao;
import com.sreekar.CFMS.model.Works;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface WorksDao extends JpaRepository<Works,Integer> {

    @Query(value="select * from works where work_requestor_id=:userId",nativeQuery = true)
    List<Works> getWorksStatus(String userId);

    @Query(value="select * from works where department=:department ORDER BY work_id ASC",nativeQuery = true)
    List<Works> getWorksByDepartment(String department);
    @Query(value="select * from works ORDER BY work_id ASC",nativeQuery = true)
    List<Works> getWorksAllDepartment();

    @Query(value = "select * from works where work_assigner_id=:facilitatorId and work_status=:status",nativeQuery = true)
    List<Works> getWorksAssigned(String facilitatorId, String status);
    @Query(value="select * from works where department=:department and work_status=:status ORDER BY work_id ASC",nativeQuery = true)

    List<Works> getWorksByDepartmentBasedOnStatus(String department,String status);
    @Query(value="select * from works where  work_status=:status ORDER BY work_id ASC",nativeQuery = true)
    List<Works> getWorksAllDepartmentBasedOnStatus(String status);
}