package com.sreekar.CFMS.controller;
import com.sreekar.CFMS.model.AssignWork;
import com.sreekar.CFMS.model.WorkStatus;
import com.sreekar.CFMS.model.Works;
import com.sreekar.CFMS.model.Workswrapper;
import com.sreekar.CFMS.service.WorksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("works")
public class WorksController {
    @Autowired
    WorksService worksService;


    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @PostMapping("addWork")
    public ResponseEntity<String> addWork(@RequestBody Works work){

        return worksService.addWork(work);
    }



    @PostMapping("updateStatus")
   @CrossOrigin(origins = "http://127.0.0.1:5502/")
    public ResponseEntity<String> updateStatus(@RequestBody WorkStatus workStatus){
        return worksService.updateStatus(workStatus);
    }

    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @PostMapping("assignWork")
    public ResponseEntity<String> assignWork(@RequestBody AssignWork assignWork) {
        return worksService.assignWork(assignWork);
    }


    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getWorkStatusByUserId")
    public ResponseEntity<List<Workswrapper>> getWorkStatus(@RequestParam String userId){
        return worksService.getWorkStatus(userId);
    }

   @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getWorksByDepartment")
    public ResponseEntity<List<Works>> getWorksByDepartment(@RequestParam String department){
        return worksService.getWorksByDepartment(department);
    }


    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getVerifyingWorksByDepartment")
    public ResponseEntity<List<Works>> getVerifyingWorksByDepartment(@RequestParam String department){
        String status= "verifying";
        return worksService.getWorksByDepartmentBasedOnStatus(department,status);
    }


    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getOngoingWorksByDepartment")
    public ResponseEntity<List<Works>> getOngoingWorksByDepartment(@RequestParam String department){
        String status= "ongoing";
        return worksService.getWorksByDepartmentBasedOnStatus(department,status);
    }

    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getCompletedWorksByDepartment")
    public ResponseEntity<List<Works>> getCompletedWorksByDepartment(@RequestParam String department){
        String status= "completed";
        return worksService.getWorksByDepartmentBasedOnStatus(department,status);
    }

    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getWorksAllDepartment")
    public ResponseEntity<List<Works>> getWorksAllDepartment(){

        return worksService.getWorksAllDepartment();
    }
    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getOngoingWorksAllDepartment")
    public ResponseEntity<List<Works>> getOngoingWorksAllDepartment(){
        String status="ongoing";
        return worksService.getWorksAllDepartmentBasedOnStatus(status);
    }

    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getVerifyingWorksAllDepartment")
    public ResponseEntity<List<Works>> getVerifyingWorksAllDepartment(){
        String status="verifying";
        return worksService.getWorksAllDepartmentBasedOnStatus(status);
    }
    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getCompletedWorksAllDepartment")
    public ResponseEntity<List<Works>> getCompletedWorksAllDepartment(){
        String status="completed";
        return worksService.getWorksAllDepartmentBasedOnStatus(status);
    }

    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getWorksAssigned")
    public ResponseEntity<List<Works>> getWorksAssigned(@RequestParam String facilitatorId,String status){
        return worksService.getWorksAssigned(facilitatorId,status);
    }

}
