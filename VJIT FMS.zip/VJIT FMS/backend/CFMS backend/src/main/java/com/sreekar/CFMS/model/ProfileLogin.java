package com.sreekar.CFMS.model;

import lombok.Data;

@Data
public class ProfileLogin {

    private String Name;
    private String userId;
    private String password;
    private String accountType;
}
