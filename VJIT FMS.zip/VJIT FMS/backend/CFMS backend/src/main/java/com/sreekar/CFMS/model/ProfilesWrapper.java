package com.sreekar.CFMS.model;

import lombok.Data;

@Data
public class ProfilesWrapper {
    private String userId;

    private String name;
    private String gmail;

    private String contactDetails;
    public ProfilesWrapper(String userId, String name, String gmail, String contactDetails){
        this.userId=userId;
        this.name=name;
        this.gmail=gmail;
        this.contactDetails=contactDetails;
    }
    public ProfilesWrapper(){
    }
}
