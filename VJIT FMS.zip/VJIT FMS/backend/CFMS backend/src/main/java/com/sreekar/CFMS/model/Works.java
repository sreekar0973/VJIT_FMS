package com.sreekar.CFMS.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;


@Data
@Entity
public class Works {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer workId;
    private String workDescription;
    private String workLocation;
    private String workStatus="verifying";
    private String workRequestorId;
    private String workAssignerId="null";
    private String department;
}