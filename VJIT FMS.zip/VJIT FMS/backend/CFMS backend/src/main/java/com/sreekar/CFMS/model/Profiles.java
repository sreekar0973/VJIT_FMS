package com.sreekar.CFMS.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Profiles {
    @Id
    private String userId;
    private String password;
    private String name;
    private String gmail;
    private String role;
    private String contactDetails;
    private String accountType;
}
