package com.sreekar.CFMS.controller;
import com.sreekar.CFMS.model.ProfileLogin;
import com.sreekar.CFMS.model.Profiles;
import com.sreekar.CFMS.model.ProfilesWrapper;
import com.sreekar.CFMS.service.ProfilesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("profiles")
public class ProfilesController {
    @Autowired
    ProfilesService profilesService;
    @PostMapping("addManyProfile")
    public ResponseEntity<String> addManyProfile(@RequestBody List<Profiles> profiles){
        return profilesService.addManyProfile(profiles);
    }
    @PostMapping("addProfile")
    public ResponseEntity<String> addProfile(@RequestBody Profiles profile){
        return profilesService.addProfile(profile);
    }
    @GetMapping("getProfile")
    public ResponseEntity<Profiles> getProfile(@RequestParam String userId){
        return profilesService.getProfile(userId);
    }
    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getProfilePassword")
    public ResponseEntity<Profiles> getProfilePassword(@RequestParam String userId){
        return profilesService.getProfilePassword(userId);
    }
    @PostMapping("deleteProfile")
    public ResponseEntity<String> deleteProfile(@RequestParam String userId){ return profilesService.deleteProfile(userId);}
    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("facilitators")
    public ResponseEntity<List<ProfilesWrapper>> getFacilitators(){
        return profilesService.getFacilitators();
    }
    @CrossOrigin(origins = "http://127.0.0.1:5502/")
    @GetMapping("getFacilitatorsByType")
    public ResponseEntity<List<ProfilesWrapper>> getFacilitatorsByType(@RequestParam String role){
        return profilesService.getFacilitatorsByType(role);
    }


}


