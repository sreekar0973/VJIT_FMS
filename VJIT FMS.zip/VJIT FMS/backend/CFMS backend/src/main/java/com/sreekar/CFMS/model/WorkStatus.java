package com.sreekar.CFMS.model;

import lombok.Data;

@Data
public class WorkStatus {
    private Integer workId;
    private String status;
}
