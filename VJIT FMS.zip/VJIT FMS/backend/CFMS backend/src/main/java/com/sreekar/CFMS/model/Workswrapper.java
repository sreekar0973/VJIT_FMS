
package com.sreekar.CFMS.model;

import lombok.Data;

@Data
public class Workswrapper {
    private Integer workId;
    private String workDescription;
    private String workLocation;
    private String workStatus;
    private String department;
    private String workAssignerId;

    public Workswrapper(Integer workId,String workDescription, String workLocation, String workStatus,String department,String workAssignerId) {
        this.workId=workId;
        this.workDescription=workDescription;
        this.workLocation=workLocation;
        this.workStatus=workStatus;
        this.department=department;
        this.workAssignerId=workAssignerId;
    }

    public Workswrapper() {

    }
}