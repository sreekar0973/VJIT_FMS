package com.sreekar.CFMS.service;
import com.sreekar.CFMS.dao.ProfilesDao;
import com.sreekar.CFMS.model.ProfileLogin;
import com.sreekar.CFMS.model.Profiles;
import com.sreekar.CFMS.model.ProfilesWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProfilesService {
    @Autowired
    ProfilesDao profilesDao;
    public ResponseEntity<String> addProfile(Profiles profile) {
        try {
            profilesDao.save(profile);
            return new ResponseEntity<>("success", HttpStatus.CREATED);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity<>("unsuccess", HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<Profiles> getProfile(String userId){
        try {
            return new ResponseEntity<>(profilesDao.findProfilesByUserId(userId), HttpStatus.FOUND);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }
    public ResponseEntity<Profiles> getProfilePassword(String userId){
        try {
            ProfileLogin pl=new ProfileLogin();
            Profiles p=profilesDao.findProfilesByUserId(userId);

            return new ResponseEntity<>(p, HttpStatus.FOUND);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }
    public ResponseEntity<String> deleteProfile(String userId) {
        try {
            profilesDao.deleteById(userId);
            return new ResponseEntity<>("success", HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity<>("unsuccess", HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<String> addManyProfile(List<Profiles> profiles) {
        try {
            for(Profiles p:profiles)
            profilesDao.save(p);
            return new ResponseEntity<>("success", HttpStatus.CREATED);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity<>("unsuccess", HttpStatus.NOT_ACCEPTABLE);

    }

    public ResponseEntity<List<ProfilesWrapper>> getFacilitators() {
        try {
            List<ProfilesWrapper> res=new ArrayList<>();
            List<Profiles> p=  profilesDao.findFacilitators();
            for(Profiles profile:p) {
                ProfilesWrapper pw=new ProfilesWrapper();
                pw.setUserId(profile.getUserId());
                pw.setName(profile.getName());
                pw.setGmail(profile.getGmail());
                pw.setContactDetails(profile.getContactDetails());
                res.add(pw);
            }
            return new ResponseEntity<>(res, HttpStatus.FOUND);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<List<ProfilesWrapper>> getFacilitatorsByType(String role) {
        try {
            List<ProfilesWrapper> res=new ArrayList<>();
            List<Profiles> p=  profilesDao.findFacilitatorsByType(role);
            for(Profiles profile:p) {
                ProfilesWrapper pw=new ProfilesWrapper();
                pw.setUserId(profile.getUserId());
                pw.setName(profile.getName());
                pw.setGmail(profile.getGmail());
                pw.setContactDetails(profile.getContactDetails());
                res.add(pw);
            }
            return new ResponseEntity<>(res, HttpStatus.FOUND);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }
}


