package com.sreekar.CFMS.service;

import com.sreekar.CFMS.dao.WorksDao;
import com.sreekar.CFMS.model.AssignWork;
import com.sreekar.CFMS.model.WorkStatus;
import com.sreekar.CFMS.model.Works;
import com.sreekar.CFMS.model.Workswrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class WorksService {
    @Autowired
    WorksDao worksDao;

    public ResponseEntity<String> addWork(Works work) {
        try {
            worksDao.save(work);
            return new ResponseEntity<>("sucesss", HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>("unsuccess", HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<String> updateStatus(WorkStatus workStatus) {
        try {
            Integer workId=workStatus.getWorkId();
            String status = workStatus.getStatus();
            Works w = worksDao.findById(workId).get();
            w.setWorkStatus(status);
            worksDao.save(w);
            return new ResponseEntity<>("sucesss", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>("unsuccess", HttpStatus.NOT_ACCEPTABLE);
    }


    public ResponseEntity<List<Workswrapper>> getWorkStatus(String userId) {
        try {
            List<Workswrapper> wrapperList = new ArrayList<>();
            List<Works> worksList = worksDao.getWorksStatus(userId);
            for (Works w : worksList)
                wrapperList.add(new Workswrapper(w.getWorkId(), w.getWorkDescription(), w.getWorkLocation(), w.getWorkStatus(), w.getDepartment(),w.getWorkAssignerId()));
            return new ResponseEntity<>(wrapperList, HttpStatus.FOUND);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }





    public ResponseEntity<String> assignWork(AssignWork assignWork) {
        try {
            Integer workId=assignWork.getWorkId();
            Works w = worksDao.findById(workId).get();
            w.setWorkStatus("ongoing");
            String workAssignerId=assignWork.getWorkAssignerId();
            w.setWorkAssignerId(workAssignerId);
            worksDao.save(w);
            return new ResponseEntity<>("sucesss", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>("unsuccess", HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<List<Works>> getWorksByDepartment(String department) {
        try {

            List<Works> ws = worksDao.getWorksByDepartment(department);
            return new ResponseEntity<>(ws, HttpStatus.FOUND);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }


    public ResponseEntity<List<Works>> getWorksAllDepartment() {
        try {

            List<Works> ws = worksDao.getWorksAllDepartment();
            return new ResponseEntity<>(ws, HttpStatus.FOUND);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }


    public ResponseEntity<List<Works>> getWorksAssigned(String facilitatorId, String status) {
        try {

            List<Works> ws = worksDao.getWorksAssigned(facilitatorId,status);
            return new ResponseEntity<>(ws, HttpStatus.FOUND);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<List<Works>> getWorksByDepartmentBasedOnStatus(String department,String status) {
        try {

            List<Works> ws = worksDao.getWorksByDepartmentBasedOnStatus(department,status);
            return new ResponseEntity<>(ws, HttpStatus.FOUND);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<List<Works>> getWorksAllDepartmentBasedOnStatus(String status) {
        try {

            List<Works> ws = worksDao.getWorksAllDepartmentBasedOnStatus(status);
            return new ResponseEntity<>(ws, HttpStatus.FOUND);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
    }
}
