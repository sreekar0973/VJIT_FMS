package com.sreekar.CFMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CFMSApplicationTests {

	@Test
	void contextLoads() {
	}

}
